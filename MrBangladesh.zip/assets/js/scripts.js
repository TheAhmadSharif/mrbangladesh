function startGame() {

	console.log("startGame");

	var userBlock = document.getElementById('userInfoSection');
	userBlock.style.display = "none";
}